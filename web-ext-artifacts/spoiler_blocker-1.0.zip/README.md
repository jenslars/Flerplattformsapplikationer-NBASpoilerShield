# Flerplattformsapplikationer-NBASpoilerShield
 Repository for school project. Firefox extension that blocks potential spoilers for NBA games. 
